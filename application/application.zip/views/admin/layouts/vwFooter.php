    <!-- latest jquery-->
    <script src="<?php echo ADMIN_ASSETS_BASE_URL; ?>js/jquery-3.5.1.min.js"></script>
    <!-- Bootstrap js-->
    <script src="<?php echo ADMIN_ASSETS_BASE_URL; ?>js/bootstrap/popper.min.js"></script>
    <script src="<?php echo ADMIN_ASSETS_BASE_URL; ?>js/bootstrap/bootstrap.js"></script>
    <!-- feather icon js-->
    <script src="<?php echo ADMIN_ASSETS_BASE_URL; ?>js/icons/feather-icon/feather.min.js"></script>
    <script src="<?php echo ADMIN_ASSETS_BASE_URL; ?>js/icons/feather-icon/feather-icon.js"></script>
    <!-- Sidebar jquery-->
    <script src="<?php echo ADMIN_ASSETS_BASE_URL; ?>js/sidebar-menu.js"></script>
    <script src="<?php echo ADMIN_ASSETS_BASE_URL; ?>js/config.js"></script>
    <!-- Plugins JS start-->
    <script src="<?php echo ADMIN_ASSETS_BASE_URL; ?>js/login.js"></script>
    <!-- Plugins JS Ends-->
    <!-- Theme js-->
    <script src="<?php echo ADMIN_ASSETS_BASE_URL; ?>js/script.js"></script>
    <!-- login js-->
    <!-- Plugin used-->
  </body>
</html>