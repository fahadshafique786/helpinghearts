		<form id="userreq_form" action="<?php echo base_url("UserRequest\getdata");?>" method="post" class="contact-form" enctype="multipart/form-data">
		  
	
		<div class="form-group">
			<input type="text" class="form-control" name="name" id="name" placeholder="Name" required/>
		  </div>
		  <div class="form-group">
			<select  class="form-control" name="country"  id="country" required />
				<option	value="">Select Country</option>
				<option	value="india"	selected>India</option>
			</select> 
		  </div>
		  <div class="form-group">
			<input type="text" class="form-control" name="phone" id="phone" placeholder="Contact No." required/>
		  </div>
		  <div class="form-group">
			<label class="text-black bold"> Upload ID Card: </label>
			<input type="file" class="form-control" name="id_card"   id="id_card"  accept=".png,.jpg,.jpeg"/>
		  </div>
		  <div class="form-group">
			<label class="text-black bold"> Upload Your Docments: </label>
			<input type="file" class="form-control" name="id_document"  id="id_document"  accept=".docx,.doc,.pdf"/>
		  </div>
		  <div class="form-group">
			<label class="text-black bold">Amount: </label>
			<input type="text" class="form-control" name="amount" id="amount" required />
		  </div>
		  <div class="form-group">
			<textarea  cols="30" rows="5" name="address" id="address" class="form-control" placeholder="Address"></textarea>
		  </div>
		  <div class="form-group">
			<input type="submit" value="SAVE" class="bold btn btn-primary">
		  </div>

	
		</form>
