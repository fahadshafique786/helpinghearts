

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="<?php echo ASSETS_URL;?>js/jquery.min.js"></script>
  <script src="<?php echo ASSETS_URL;?>js/jquery-migrate-3.0.1.min.js"></script>
  <script src="<?php echo ASSETS_URL;?>js/popper.min.js"></script>
  <script src="<?php echo ASSETS_URL;?>js/bootstrap.min.js"></script>
  <script src="<?php echo ASSETS_URL;?>js/jquery.easing.1.3.js"></script>
  <script src="<?php echo ASSETS_URL;?>js/jquery.waypoints.min.js"></script>
  <script src="<?php echo ASSETS_URL;?>js/jquery.stellar.min.js"></script>
  <script src="<?php echo ASSETS_URL;?>js/owl.carousel.min.js"></script>
  <script src="<?php echo ASSETS_URL;?>js/jquery.magnific-popup.min.js"></script>
  <script src="<?php echo ASSETS_URL;?>js/aos.js"></script>
  <script src="<?php echo ASSETS_URL;?>js/jquery.animateNumber.min.js"></script>
  <script src="<?php echo ASSETS_URL;?>js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="<?php echo ASSETS_URL;?>js/google-map.js"></script>
  <script src="<?php echo ASSETS_URL;?>js/main.js"></script>
    
  <!-- sweetalert JS-->
  <script src="<?php echo ASSETS_URL;?>js/sweetalert.min.js"></script>
  
<script>
function paymentConfirmation()
{
	var check = true;
		$(".require").each(function (item) {
			$(this).removeClass("error");
			if($(this).val() == "" || $(this).val() == " ")
			{
				$(this).addClass("error");
				check = false;
			}
		});
		
		if(!check)
		{
			swal("Error", "Please Fill All required Fields", "error");
			return false;
		}

		if(check)
		{
			var type 		= $("#contribution_type option:selected").text();
			var cname 		= $("#name").val();
			var cemail 		= $("#email").val();
			var contact 	= $("#contact_no").val();
			var amount 		= $("#amount").val();
			
			var	msg ="<table class='confirmation_table' border='1' style='border: 1px solid #ccc !important;box-shadow: 2px 1px 8px #ccc;border-collapse:collapse;;width:100%'><tr><td>Contribution Type</td><td>"+type+"</td></tr><tr><td>Name</td><td>"+cname+"</td></tr><tr><td>Email</td><td>"+cemail+"</td></tr><tr><td>Contact No.</td><td>"+contact+"</td></tr><tr><td>Amount</td><td>"+amount+"</td></tr></table>";
		  
			  const wrapper = document.createElement('div');
			  wrapper.innerHTML = msg;

			  swal({
				  title: "Please Review Your Donation",
				  content: wrapper, 
				  icon: "info",
				  className: "order_confirmation_swal",
				  buttons: [
					'Cancel',
					'Confirm Donation'
				  ],
				  dangerMode: false,
				}).then(function(isConfirm) {
				  if (isConfirm){
						$("#donation_form").attr("action",'<?= base_url("Home/SaveDonation");?>');
						$("#SaveBtn").trigger("click");
					} 
				});
		}	
}

function launchBOLT()
{
	bolt.launch({
	key: $('#key').val(),
	txnid: $('#txnid').val(), 
	hash: $('#hash').val(),
	amount: $('#amount').val(),
	firstname: $('#fname').val(),
	email: $('#email').val(),
	phone: $('#mobile').val(),
	productinfo: $('#pinfo').val(),
	udf5: $('#udf5').val(),
	surl : $('#surl').val(),
	furl: $('#surl').val(),
	mode: 'dropout'	
},{ responseHandler: function(BOLT){
	console.log( BOLT.response.txnStatus );		
	if(BOLT.response.txnStatus != 'CANCEL')
	{
		//Salt is passd here for demo purpose only. For practical use keep salt at server side only.
		var fr = '<form action=\"'+$('#surl').val()+'\" method=\"post\">' +
		'<input type=\"hidden\" name=\"key\" value=\"'+BOLT.response.key+'\" />' +
		'<input type=\"hidden\" name=\"salt\" value=\"'+$('#salt').val()+'\" />' +
		'<input type=\"hidden\" name=\"txnid\" value=\"'+BOLT.response.txnid+'\" />' +
		'<input type=\"hidden\" name=\"amount\" value=\"'+BOLT.response.amount+'\" />' +
		'<input type=\"hidden\" name=\"productinfo\" value=\"'+BOLT.response.productinfo+'\" />' +
		'<input type=\"hidden\" name=\"firstname\" value=\"'+BOLT.response.firstname+'\" />' +
		'<input type=\"hidden\" name=\"email\" value=\"'+BOLT.response.email+'\" />' +
		'<input type=\"hidden\" name=\"udf5\" value=\"'+BOLT.response.udf5+'\" />' +
		'<input type=\"hidden\" name=\"mihpayid\" value=\"'+BOLT.response.mihpayid+'\" />' +
		'<input type=\"hidden\" name=\"status\" value=\"'+BOLT.response.status+'\" />' +
		'<input type=\"hidden\" name=\"hash\" value=\"'+BOLT.response.hash+'\" />' +
		'</form>';
		var form = jQuery(fr);
		jQuery('body').append(form);								
		form.submit();
	}
},
	catchException: function(BOLT){
 		alert( BOLT.message );
	}
});
}
</script>
<!-- Modal -->
<div id="useerRequestModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">User <span class="text-primary">Request</span></h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">

			<?php $this->load->view('forms/vwUserRequestForm'); ?>

      </div>
    </div>

  </div>
</div>	
	
	
  </body>
</html>