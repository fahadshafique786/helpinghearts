<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model("Login_Model");		
 	}
 
   	public function index()
	{
		$this->load->view('admin/vwLogin');	
	}

	public function checklogin()	
	{
		$user_name	=	$this->input->post('user_name',TRUE);		
		$password		=	$this->input->post('password',TRUE);
		$check          =   $this->Login_Model->validate($user_name,$password);
		if($check->num_rows() >0 )
		{
			$data		=	$check->row_array();
			$uname		=	$data['user_name'];
			$roleid		=	$data['role_id'];
			$sessionData=array(
				'username' =>$uname,
				'roleid'   =>$roleid,
				'log_in'   =>TRUE
			);
			$this->session->set_userdata($sessionData);	
			if($roleid =='1')
			{
				redirect('Dashboard');
			}
		}
		else{
			echo $this->session->set_flashdata('msg','user name or password wrong');
			redirect('admin/vwLogin');
		}
	}
}
