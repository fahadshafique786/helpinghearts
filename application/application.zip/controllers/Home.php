<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	
	function __construct(){
		parent::__construct();
		$this->load->model("Common_Model","common");	
 	}
	
	public function index()
	{
		$para = array();
		$para['select'] 		= '*';
		$para['table'] 			= 'donation_type';
		$para['whereArr'] 		= array( "donation_type.is_status" => 1, "donation_type.is_deleted" => 0 );
		$data['donation_type']	= $this->common->getAllParameters($para);
			
		$this->load->view('vwHome',$data);
	}
	
	public function SaveDonation()
	{
		$name 				= (isset($_POST['name']) && !empty($_POST['name'])) ? $_POST['name'] : false;
		$email 				= (isset($_POST['email']) && !empty($_POST['email'])) ? $_POST['email'] : false;
		$phone 				= (isset($_POST['contact_no']) && !empty($_POST['contact_no'])) ? $_POST['contact_no'] : false;
		$contribution_type 	= (isset($_POST['contribution_type']) && !empty($_POST['contribution_type'])) ? $_POST['contribution_type'] : false;
		$amount 			= (isset($_POST['amount']) && !empty($_POST['amount'])) ? $_POST['amount'] : false;
						
		$save_array['name'] 		= $name;
		$save_array['email'] 		= $email;
		$save_array['cell'] 		= $phone;
		$save_array['type_id'] 		= $contribution_type;
		$save_array['amount'] 		= $amount;
		$save_array['status'] 		= "Pending";
		$save_array['reference_no'] = 'Txn-'.time().rand(111111,999999);;
		
		$table 		= "donation";
		$lastId 	= $this->common->Save($save_array,$table);
	
		redirect('/Home/RequestforPayment');
		
	}

	public function RequestforPayment()
	{
		$this->load->view('payumoney/index');
	}
	
}
