<?php  
defined('BASEPATH') OR exit('No direct script access allowed');
	
class Common_Model extends CI_Model {

    function __construct()
    {
        parent::__construct();
    }

	public function Save($data,$table)
	{
		$this->db->insert($table, $data);
		return $this->db->insert_id();
	}
	
	public function update($data,$table,$where)
	{
		$this->db->where($where);
		$this->db->update($table, $data);
		return true;
	}
	
	public function common_delete($table,$where)
	{
		$this->db->where($where);
		$this->db->delete($table); 
		return true;
	}
	
	public function getAllParameters($parameter = array())
  	{
		if(!empty($parameter))
		{
			$select 		= (isset($parameter['select']) && !empty($parameter['select'])) ? $parameter['select'] : "*";
			$table 			= (isset($parameter['table']) && !empty($parameter['table'])) ? $parameter['table'] : false;
			$whereArr 		= (isset($parameter['whereArr']) && !empty($parameter['whereArr'])) ? $parameter['whereArr'] : false;
			$order 			= (isset($parameter['order']) && !empty($parameter['order'])) ? $parameter['order'] : false;
			$sort 			= (isset($parameter['sort']) && !empty($parameter['sort'])) ? $parameter['sort'] : false;
			$sLimit 		= (isset($parameter['sLimit']) && !empty($parameter['sLimit'])) ? $parameter['sLimit'] : false;
			$offset 		= (isset($parameter['offset']) && !empty($parameter['offset'])) ? $parameter['offset'] : false;
			$result_array 	= (isset($parameter['result_array']) && !empty($parameter['result_array'])) ? $parameter['result_array'] : false;
			$num_rows 		= (isset($parameter['num_rows']) && !empty($parameter['num_rows'])) ? $parameter['num_rows'] : false;
			$db_group 		= (isset($parameter['db_group']) && !empty($parameter['db_group'])) ? $parameter['db_group'] : "default";
			
			if(!empty($table))
			{
				if($db_group !="default")
				
				$this->load->database($db_group, TRUE);	
				$this->db->select($select);
				$this->db->from($table);
				if($whereArr!="")
				$this->db->where($whereArr);
				if($sLimit!='' && $offset!='')
				$this->db->limit($sLimit,$offset);
				elseif($sLimit!='')
				$this->db->limit($sLimit);
				
				if($order!='' && $sort!='')
				{
					$this->db->order_by($order,$sort);
				}
				$query = $this->db->get();

				if($query->num_rows() == 0)
					return false;				  
				else
				{
					if($num_rows==true)
					return $query->num_rows();
					if($result_array==true)
						$result = $query->result_array();
					else
						$result = $query->result();
					return $result;				  
				}
			}
			
		}
	}

	public function getParameters($parameter = array())
  	{
		if(!empty($parameter))
		{
			$select 		= (isset($parameter['select']) && !empty($parameter['select'])) ? $parameter['select'] : "*";
			$table 			= (isset($parameter['table']) && !empty($parameter['table'])) ? $parameter['table'] : false;
			$whereArr 		= (isset($parameter['whereArr']) && !empty($parameter['whereArr'])) ? $parameter['whereArr'] : false;
			$result_array 	= (isset($parameter['result_array']) && !empty($parameter['result_array'])) ? $parameter['result_array'] : false;
			$num_rows 		= (isset($parameter['num_rows']) && !empty($parameter['num_rows'])) ? $parameter['num_rows'] : false;

			if(!empty($table))
			{
				$this->db->select($select);
				$this->db->from($table);
				if($whereArr!='')
				$this->db->where($whereArr);
				$query = $this->db->get();
				if($query->num_rows() == 0)
					return false;				  
				else
				{
					if($num_rows==true)
						return $query->num_rows();
						
					if($result_array==true)
						$result = $query->result_array();
					else
						$result = $query->result();
					return $result[0];				  
				}
			}
		}
	}

	public function get_num_of_rows($parameter = array())
	{
		if(!empty($parameter))
		{
			$select 		= (isset($parameter['select']) && !empty($parameter['select'])) ? $parameter['select'] : "*";
			$table 			= (isset($parameter['table']) && !empty($parameter['table'])) ? $parameter['table'] : false;
			$whereArr 		= (isset($parameter['whereArr']) && !empty($parameter['whereArr'])) ? $parameter['whereArr'] : false;
			
			if(!empty($table))
			{
				$this->db->select($select);
				$this->db->from($table);
				if($whereArr!="")
				$this->db->where($whereArr);
				$query = $this->db->get();
				return $query->num_rows();
			}
		}
	}
	
	
}
?>