<?php

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function SaveCMSLogs($parameter)
{
	$CI =& get_instance();
	
	if($parameter)
	{
		//echo '<pre>';
		$tname 			= (isset($parameter['tname']) && !empty($parameter['tname'])) ? $parameter['tname'] : false;
		$dbobj 			= (isset($parameter['dbobj']) && !empty($parameter['dbobj'])) ? $parameter['dbobj'] : false;
		
		$tbl_array = array();
		if(!empty($tname) && !empty($dbobj))
		{
			$showTblSql = "SHOW TABLES";
			$showTblQuery = mysqli_query($dbobj,$showTblSql);
			if(mysqli_num_rows($showTblQuery) > 0 )
			{   
				while($loadTbldata = mysqli_fetch_array($showTblQuery))
				{
					$tbl_array[] = $loadTbldata[0];
				}
			}
			
			if(!empty($tbl_array))
			{
				$tblCheck = in_array($tname,$tbl_array);
				if($tblCheck)
				{
					$module 		= (isset($parameter['module']) && !empty($parameter['module'])) ? $parameter['module'] : false;
					$action 		= (isset($parameter['action']) && !empty($parameter['action'])) ? $parameter['action'] : false;
					$description 	= (isset($parameter['description']) && !empty($parameter['description'])) ? $parameter['description'] : false;
					$actor_id 		= (isset($parameter['actor_id']) && !empty($parameter['actor_id'])) ? $parameter['actor_id'] : false;
					$cname 			= (isset($parameter['cname']) && !empty($parameter['cname'])) ? $parameter['cname'] : false;
					$id 			= (isset($parameter['pri_id']) && !empty($parameter['pri_id'])) ? $parameter['pri_id'] : false;
					
					if(!empty($cname))
					{
						$selectSql = "SELECT * FROM ".$tname;
						if($action == "create")
						{
							$selectSql .= " where ".$cname." = '".$actor_id."' ORDER BY id DESC LIMIT 1 ";
						}
						else
						{
							$selectSql .= " where ".$cname." = '".$id."' LIMIT 1 ";
						}
						
						$selectQuery = mysqli_query($dbobj,$selectSql);
						if(mysqli_num_rows($selectQuery) > 0 )
						{   
							$selectdata = mysqli_fetch_assoc($selectQuery);
							if(!empty($selectdata))
							{
								$action_id = $selectdata['id'];
								$json_data = json_encode($selectdata);
								$saveSql = "INSERT INTO cms_logs (module,action_id,modified_data,action,description,updated_by)VALUES('" . trim($module) . "','" . trim($action_id) . "','" . $json_data . "','" . trim($action) . "','" . trim($description) . "','" . trim($actor_id) . "')";
								$saveQuery = mysqli_query($dbobj,$saveSql);
							}
						}
					}
					
				}
			}
		}
	}

}

function calculateTimeDifference($date1)
{
	if($date1)
	{
		$date2 =  date('Y-m-d H:i:s') ;
		
		$datetime1 = new DateTime($date2);
		$datetime2 = new DateTime($date1);
		$interval = $datetime2->diff($datetime1);
		
		$data['hours']	= $interval->format('%h');		
		$data['minutes']	= $interval->format('%i');		
		$data['seconds']	= $interval->format('%s');		
		
		return $data;
	}
	else
	{
		return false;
	}

}

function create_csrfinput()
{
	$CI =& get_instance();
	$csrf = array(
		'name' => $CI->security->get_csrf_token_name(),
		'hash' => $CI->security->get_csrf_hash()
	);
							
	$input = '<input type="hidden" name="'.$csrf['name'].'" value="'.$csrf['hash'].'" />';
	return $input;
}

function setExcelDateExcludeTiming($date)
{
	$time = strtotime($date);
	$final_date = floor($time/86400)*86400;		
	return $final_date;
}

function download($data)
{	
	$path 				= (!empty($data) && isset($data['path'])) ? $data['path'] : '';
	$uniqueFileName 	= (!empty($data) && isset($data['uniqueFileName'])) ? $data['uniqueFileName'] : '';
	$originalFileName 	= (!empty($data) && isset($data['originalFileName'])) ? $data['originalFileName'] : '';
	
	if(!empty($path))
	{
		$path .='/'. $uniqueFileName;
		if(file_exists ($path ))
		{	
			$file = fopen($path,"r");
			$content=fread($file,filesize($path));
			fclose($file);
				
			$size = strlen($content);
			header('Content-Type: application/octet-stream');
			header('Content-Length: '.$size);
			header('Content-Disposition: attachment; filename='.$uniqueFileName);
			header('Content-Transfer-Encoding: binary');
			echo $content;
			//@unlink($path);
		 exit;
		}
	} 
}

function createControllerFile($data)
{
	$msg = "";
	$class_name = (!empty($data) && isset($data['cname'])) ? ucfirst($data['cname']) : false;
	$view_name = (!empty($data) && isset($data['vname'])) ? strtolower($data['vname']) : "welcome_message";
	if(!empty($class_name))
	{
		$FileName = "sample_controller.txt";
		$path = ABS_BASE_PATH_SAMPLE_FILE. $FileName;
		if(file_exists($path))
		{
			$class_name = str_replace(" ","_",$class_name);
			$view_name = "vw".ucfirst(str_replace(" ","_",$view_name));
			$sample_content = file_get_contents($path);		
			$New_content = str_replace("sample_controller",$class_name,$sample_content);
			$final_content = str_replace("sample_view",$view_name,$New_content);
			$class_file_name = $class_name.".php";
			$class_file_path = ABS_BASE_PATH_CONTROLLER.$class_file_name;
			if(!file_exists($class_file_path))
			{
				$final_content = "<?php ".$final_content." ?>";
				
				$createNewfile = fopen($class_file_path, "w") or die("Unable to open file!");
				fwrite($createNewfile, $final_content);
				fclose($createNewfile);
			
				$msg = "Controller Successfully Created";
			}else{
				$msg = "Controller Already Exist";
			}
		}else{
			$msg = "Sample Controller is Missing";
		}
	}else{
		$msg = "Parameter Missing";
	}	
	
	return $msg;
}	

function createViewFile($data)
{
	$msg = "";
	$view_name = (!empty($data) && isset($data['vname'])) ? strtolower($data['vname']) : "welcome_message";
	if(!empty($view_name))
	{
		$FileName = "sample_view.txt";
		$path = ABS_BASE_PATH_SAMPLE_FILE. $FileName;
		if(file_exists($path))
		{
			$sample_content = file_get_contents($path);
			$final_content = str_replace("sample_view",$view_name,$sample_content);
			$view_file_name =  "vw".ucfirst(str_replace(" ","_",$view_name)).".php";
			$view_file_path = ABS_BASE_PATH_VIEW.$view_file_name;
			if(!file_exists($view_file_path))
			{				
				$createNewfile = fopen($view_file_path, "w") or die("Unable to open file!");
				fwrite($createNewfile, $final_content);
				fclose($createNewfile);
			
				$msg = "View Successfully Created";
			}else{
				$msg = "View Already Exist";
			}
			
		}else{
			$msg = "Sample View is Missing";
		}
	}else{
		$msg = "Parameter Missing";
	}	
	
	return $msg;
}	

function debug($data,$flag=true)
{
	echo "<pre>"; 
	print_r($data); 
	
	if($flag)
		die;
}

function hasChild($parent_id)
{
	$CI =& get_instance();
	$sql = $CI->db->query("SELECT COUNT(*) as count FROM menu WHERE parent_id = '" . $parent_id . "'")->row();
	return $sql->count;
}
	
function MeunList()
{
	$CI =& get_instance();
	$CI->load->model("Common_model","common");
	
	$parent_id = 0;
	$where = array( "parent_id" => $parent_id , "m_status" => 1 , "is_deleted" => 0 );
	$parameter = array();
	$parameter['select'] = '*';
	$parameter['table'] = 'menu';
	$parameter['whereArr'] = $where;
	$parameter['result_array'] = false;
	$parentMeundata = $CI->common->getAllParameters($parameter);
	$list = "";
	
	
//	echo $CI->db->last_query();


	//$mainlist = '<ul class="nav-menu custom-scrollbar">';
	$mainlist = '';
	if($parameter['result_array'] ==  true){
		foreach($parentMeundata as $pr){
			$mainlist .= MenuTree($list,$pr['id'],$pr['m_name'],$append = 0 ,$pr['level'],$pr['link']);
		}	
	}
	else
	{
		foreach($parentMeundata as $pr){
			$mainlist .= MenuTree($list,$pr->id,$pr->m_name,$append = 0,$pr->level,$pr->link);
		}
	}


	$list .= "</li>";
	//$list .= "</li></ul>";
	return  $mainlist;
}

function MenuTree($list,$id,$name,$append,$level,$link)
{
	$CI =& get_instance();
	$CI->load->model("Common_model","common");
	
	$hasChild = hasChild($id);
	
	if( $level >= 2 && $hasChild >= 1 )
	{
		$ulClass = "nav-sub-childmenu submenu-content";
		if($hasChild)
			$list = '<li><a class="submenu-title" href="'.$link.'">'.$name.'<span class="sub-arrow"><i class="fa fa-chevron-right"></i></span></a>';
		else
			$list = '<li><a class="submenu-title" href="'.$link.'">'.$name.'</a>';
	}
	else
	{
		$ulClass = "nav-submenu menu-content";
		$list = '<li class="dropdown"><a class="nav-link menu-title" href="'.$link.'">'.$name.'</a>';
	}
		
	if ($hasChild) // check if the id has a child
	{
		$append++;
		$list .= '<ul class="'.$ulClass.'" '.$level.'>';

		$where = array( "parent_id" => $id , "m_status" => 1 , "is_deleted" => 0 );
		$parameter = array();
		$parameter['select'] = '*';
		$parameter['table'] = 'menu';
		$parameter['whereArr'] = $where;
		$childMeundata = $CI->common->getAllParameters($parameter);
	
		foreach($childMeundata as $pr){
			$list .= MenuTree($list,$pr->id,$pr->m_name,$append,$pr->level,$pr->link);
		};
		$list .= "</ul>";
	}
	return $list;
}
	
	if( !function_exists('local_to_mysql()')){
        function local_to_mysql($date){
            return date('Y-m-d', strtotime(str_replace('-', '/', $date)));
        }
    }

    if( !function_exists('mysql_to_local()')){
        function mysql_to_local($date){
            return date('m-d-y', strtotime(str_replace('-', '/', $date)));
        }
    }
	 
?>
